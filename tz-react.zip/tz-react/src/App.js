import React from 'react';
import logo from './logo.svg';
import './App.css';
import YourName from'./components/YourName'

function App() {
  return (
    <YourName manName = {"vasya"} 
              inputId = {"name"} 
              wrapBorder = {"1px solid gray"} 
              someText = {"Some text here"} 
              labelText = {"Enter your name: "}/>
  );
}

export default App;

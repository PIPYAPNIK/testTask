import React from 'react';

const YourName = props => {
    return (
        <div className="form-item">
            <div className={props.manName} style={{border: props.wrapBorder}}>
                <label for={props.inputId}>{props.labelText}</label>
                <input type="text" id={props.inputId} />
            </div>
            <p>{props.someText}</p> 
        </div>
    );
};

export default YourName;